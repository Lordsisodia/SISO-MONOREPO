
import { TestimonialSection } from '../TestimonialSection';

export const TestimonialsSection = () => {
  return (
    <section id="testimonials" className="py-16">
      <TestimonialSection />
    </section>
  );
};

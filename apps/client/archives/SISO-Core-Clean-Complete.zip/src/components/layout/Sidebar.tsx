// Add to navigation items
const navigationItems = [
  // ... existing items ...
  {
    icon: FlaskConical,
    label: 'AI Testing',
    path: '/testing',
    description: 'Test AI prompts and responses'
  },
  // ... existing items ...
]; 
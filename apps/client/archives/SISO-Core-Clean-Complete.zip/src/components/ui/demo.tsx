import * as React from "react"
import { AIAssistantInterface } from "@/components/ui/ai-assistant-interface"

export function Demo() {
  return (
    <div className="w-screen">
      <AIAssistantInterface />
    </div>
  )
}
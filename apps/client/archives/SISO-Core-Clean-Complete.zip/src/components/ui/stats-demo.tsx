import { Stats } from "@/components/ui/stats-section-with-text"

function StatsDemo() {
  return (
    <div className="w-full bg-black">
      <Stats />
    </div>
  );
}

export { StatsDemo };

// [Analysis] User comment type
export interface NewsComment {
  id: string;
  content: string;
  created_at: string;
  user_email: string;
  updated_at: string;
  news_id: string;
}
